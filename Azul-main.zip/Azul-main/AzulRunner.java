public class AzulRunner {
	public static void main(String[] args) {
		FirstAzulJava game = new FirstAzulJava ("Azul");
	}

}
